$(function(){
	$(".header .headerRight li").hover(
		function(){
			$(this).addClass("cur");
		},
		function(){
			$(this).removeClass("cur");
		}
	)

	if($(".newsList .globalArrowBtn").length > 0){
		$(".newsList .globalArrowBtn").on("click",function(){
			if($(this).parents(".newsCon").hasClass("cur")){
				$(this).parents(".newsCon").removeClass("cur");
			}else{
				$(this).parents(".newsCon").addClass("cur");
			}
		})
	}
	

})